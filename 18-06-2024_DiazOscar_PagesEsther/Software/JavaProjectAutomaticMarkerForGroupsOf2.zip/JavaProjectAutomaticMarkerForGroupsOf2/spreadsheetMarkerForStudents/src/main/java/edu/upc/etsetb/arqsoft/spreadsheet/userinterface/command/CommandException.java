/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.upc.etsetb.arqsoft.spreadsheet.userinterface.command;

/**
 *
 * @author oscar
 */
public class CommandException extends Exception{
    public CommandException(String msg) {
        super(msg);
    }
}
