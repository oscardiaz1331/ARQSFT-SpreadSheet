/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.upc.etsetb.arqsoft.spreadsheet.exceptions;

/**
 *
 * @author oscar
 */
public class MathErrorException extends Exception {
    public MathErrorException(String msg) {
        super(msg);
    }
}
