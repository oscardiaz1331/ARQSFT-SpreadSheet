/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package edu.upc.etsetb.arqsoft.spreadsheet.userinterface.entities;

import edu.upc.etsetb.arqsoft.spreadsheet.domainmodel.Spreadsheet;

/**
 *
 * @author oscar
 */
public interface ISaveSpreadSheet {
    public void save(String filename ,Spreadsheet spreadsheet);
}
